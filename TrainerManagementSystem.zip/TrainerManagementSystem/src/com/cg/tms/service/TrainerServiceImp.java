package com.cg.tms.service;

import java.util.regex.Pattern;

import com.cg.tms.Exceptions.TrainerException;
import com.cg.tms.bean.TrainerDetailsdto;
import com.cg.tms.dao.TrainerDaoImp;

public class TrainerServiceImp {
	TrainerDaoImp dao=new TrainerDaoImp();
	public boolean isValidateTname(String tname) {
		String pattern="[A-Z a-z]{5,20}";
		if(Pattern.matches(pattern, tname))
		{
		return true;
		}
		else
		{
		return false;
		}
	}

	public boolean isValidPhn(String phn) {
		String pattern="[7-9][0-9]{9}";
		if(Pattern.matches(pattern, phn))
		{
		return true;
		}
		else
		{
		return false;
		}
	}
	public TrainerDetailsdto adddetails(TrainerDetailsdto dto) throws TrainerException
	{
		return dao.adddetails(dto);
		
	}
	public int getTrainerId() throws TrainerException {
		return dao.getTrainerId();
	}

}
