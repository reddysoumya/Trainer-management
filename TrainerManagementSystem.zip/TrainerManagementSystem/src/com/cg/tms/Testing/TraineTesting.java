package com.cg.tms.Testing;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.tms.Exceptions.TrainerException;
import com.cg.tms.bean.TrainerDetailsdto;
import com.cg.tms.dao.TrainerDaoImp;
public class TraineTesting 
{
	static TrainerDaoImp dao=new TrainerDaoImp();
	static TrainerDetailsdto dto=new TrainerDetailsdto();	
	@BeforeClass
	public static void setuptest1() {
	dao = new TrainerDaoImp();
	}
	@AfterClass
	public static void setuptest2() {
	dao = null;
	}
	@After
	public static void setuptest3() {
	dto = null;
	}
	@Before
	public void setUPtest() throws Exception {
	dto = new TrainerDetailsdto();
	}
	@Test
	public TrainerDetailsdto adddetails(TrainerDetailsdto dto) throws TrainerException{
		dto.setTname("Bindu");
		dto.setLocation("Hyderabad");
		dto.setDesignation("consultant");
		dto.setTechnology("jee");
		dto.setPhn("8789098765");
		try {
			int id = dao.getTrainerId();
		Assert.assertNotSame(0, id);
		} catch(TrainerException e) {
		Assert.fail();
		}
		return dto;
		
	}

}
